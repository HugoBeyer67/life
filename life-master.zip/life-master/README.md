## Game of Life in Javascript with React.js

Demo: [http://damiankao.github.io/life/](http://damiankao.github.io/life/)

Javascript + HTML5 implementation of a cellular automata. Everything was done with React.js.

Need to do:

  - Refactor the code so the instructions and settings UI elements are separate from the board component.
  - Move javascript style definitions to separate CSS file.
  - Support .RLE pattern files.
